import tkinter as tk
from tkinter import *
from tkinter import ttk

def add_hint(entry, hint, is_password=False):
    entry.insert(0, hint)
    entry.config(fg='grey')
    
    def on_focus_in(event):
        if entry.get() == hint:
            entry.delete(0, 'end')
            entry.config(fg='black')
            if is_password:
                entry.config(show="*")  # Mask password if it's the password field

    def on_focus_out(event):
        if not entry.get():
            entry.insert(0, hint)
            entry.config(fg='grey')
            if is_password:
                entry.config(show="")  # Show hint text (unmasked)
    
    entry.bind("<FocusIn>", on_focus_in)
    entry.bind("<FocusOut>", on_focus_out)

# Initialize the root window
root = tk.Tk()
root.title("Modern Sign-Up Page")
root.geometry('400x600')
root.minsize(height=600, width=400)
root.config(bg='#34a4eb')




# Create a Frame with a semi-transparent effect
frame = tk.Frame(root, width=350, height=450, bg='#ffffff', bd=0, relief=tk.RIDGE,padx=50,pady=5)
frame.place(relx=0.5, rely=0.5, anchor=CENTER)

# Add a modern border (simulated shadow effect)
# frame.config(highlightbackground="#e0e0e0", highlightthickness=1)

im = PhotoImage(file="userlogin.png")
ilabel = tk.Label(frame, image=im, bg='#ffffff')
ilabel.pack(pady=(10, 10))

# Title Label
title_label = tk.Label(frame, text="Sign Up", font=("Helvetica", 24, "bold"), bg='#ffffff', fg='#333')
title_label.pack(pady=(0, 20))

# Create and style Entries inside the frame
e1 = tk.Entry(frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
e1.config(bg='#f5f5f5', insertbackground='#000')

e2 = tk.Entry(frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
e2.config(bg='#f5f5f5', insertbackground='#000')

e3 = tk.Entry(frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
e3.config(bg='#f5f5f5', insertbackground='#000')

e4 = tk.Entry(frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
e4.config(bg='#f5f5f5', insertbackground='#000')

# Add hint text to entry fields
add_hint(e1, "👤 Enter your username")
add_hint(e2, "📧 Enter your email")
add_hint(e3, "🔑 Enter your password", is_password=True)
add_hint(e4, "🔒 Confirm your password", is_password=True)

# Custom modern styled button using ttk
style = ttk.Style()
style.configure('TButton', font=('Helvetica', 12), padding=10, background='#3a86ff')

# Creating separate styles for normal and hover states
style.configure('TButton.Normal.TButton', background='#3a86ff', font=('Helvetica', 15))
style.configure('TButton.Hover.TButton', background='#1e5baf', foreground='#1e5baf', font=('Helvetica', 15))

b1 = ttk.Button(frame, text="Sign Up", style="TButton.Normal.TButton", cursor="hand2")
Signup_label = tk.Label(frame, text="Already have a Account?", font=("Helvetica", 10, "underline"), bg='#ffffff', fg='#3a86ff', cursor="hand2")

# Button hover effect using styles
def on_enter(event):
    b1.config(style="TButton.Hover.TButton")

def on_leave(event):
    b1.config(style="TButton.Normal.TButton")

b1.bind("<Enter>", on_enter)
b1.bind("<Leave>", on_leave)

# Place the widgets in the frame with appropriate padding
e1.pack(pady=(25, 5), ipadx=10, ipady=7, fill=tk.X)
e2.pack(pady=(15, 5), ipadx=10, ipady=7, fill=tk.X)
e3.pack(pady=(15, 5), ipadx=10, ipady=7, fill=tk.X)
e4.pack(pady=(15, 5), ipadx=10, ipady=7, fill=tk.X)
b1.pack(pady=(30,5), fill=tk.X)
Signup_label.pack()


root.mainloop()
