import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import messagebox

# Function to add hint text to entry fields
def add_hint(entry, hint, is_password=False):
    """Add hint text to the entry widget and manage focus events for hint visibility."""
    entry.insert(0, hint)
    entry.config(fg='grey')

    def on_focus_in(event):
        if entry.get() == hint:
            entry.delete(0, 'end')
            entry.config(fg='black')
            if is_password:
                entry.config(show="*")  # Mask password if it's the password field

    def on_focus_out(event):
        if not entry.get():
            entry.insert(0, hint)
            entry.config(fg='grey')
            if is_password:
                entry.config(show="")  # Show hint text (unmasked)

    entry.bind("<FocusIn>", on_focus_in)
    entry.bind("<FocusOut>", on_focus_out)

# Function to handle the "Login" button click
def handle_login_click():
    username = login_e1.get()
    password = login_e2.get()

    # Basic validation
    if username == "" or username == "👤 Enter your username":
        messagebox.showerror("Input Error", "Please enter a valid username.")
        return
    if password == "" or password == "🔑 Enter your password":
        messagebox.showerror("Input Error", "Please enter your password.")
        return

    messagebox.showinfo("Success", "Login successful!")
    print(f"Login Info:\nUsername: {username}\nPassword: {password}")

# Function to handle the "Sign Up" button click
def handle_signup_click():
    username = signup_e1.get()
    email = signup_e2.get()
    password = signup_e3.get()
    confirm_password = signup_e4.get()

    # Basic validation
    if username == "" or username == "👤 Enter your username":
        messagebox.showerror("Input Error", "Please enter a valid username.")
        return
    if email == "" or email == "📧 Enter your email":
        messagebox.showerror("Input Error", "Please enter a valid email.")
        return
    if password == "" or password == "🔑 Enter your password":
        messagebox.showerror("Input Error", "Please enter a password.")
        return
    if confirm_password == "" or confirm_password == "🔒 Confirm your password":
        messagebox.showerror("Input Error", "Please confirm your password.")
        return
    if password != confirm_password:
        messagebox.showerror("Input Error", "Passwords do not match.")
        return

    messagebox.showinfo("Success", "You have successfully signed up!")
    print(f"Signup Info:\nUsername: {username}\nEmail: {email}\nPassword: {password}")

# Function to switch to the login frame
def open_login():
    signup_frame.place_forget()  # Hide signup frame
    login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Show login frame centered

# Function to switch to the signup frame
def open_signup():
    login_frame.place_forget()  # Hide login frame
    signup_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Show signup frame centered

# Initialize the root window
root = tk.Tk()
root.title("Modern Login and Sign-Up Page")
root.geometry('400x600')
root.minsize(height=600, width=400)
root.config(bg='#34a4eb')

# Centering the frames dynamically in the window
def center_window(window):
    window.update_idletasks()
    width = window.winfo_width()
    height = window.winfo_height()
    x = (window.winfo_screenwidth() // 2) - (width // 2)
    y = (window.winfo_screenheight() // 2) - (height // 2)
    window.geometry(f'{width}x{height}+{x}+{y}')

# Call this after widgets are placed to center the window
root.after(100, lambda: center_window(root))

# Common Style for Buttons
style = ttk.Style()
style.configure('TButton', font=('Helvetica', 12), padding=10, background='#3a86ff')
style.configure('TButton.Normal.TButton', background='#3a86ff', font=('Helvetica', 15))
style.configure('TButton.Hover.TButton', background='#1e5baf', foreground='#1e5baf', font=('Helvetica', 15))

# ========================== LOGIN FRAME ==========================
login_frame = tk.Frame(root, width=350, height=400, bg='#ffffff', padx=30, pady=5)

# Image and Title for Login
login_im = PhotoImage(file="userlogin.png")
login_ilabel = tk.Label(login_frame, image=login_im, bg='#ffffff')
login_ilabel.pack()
login_title_label = tk.Label(login_frame, text="Login", font=("Helvetica", 24, "bold"), bg='#ffffff', fg='#333')
login_title_label.pack()

# Login Entry Fields
login_e1 = tk.Entry(login_frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
login_e2 = tk.Entry(login_frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")

add_hint(login_e1, "👤 Enter your username")
add_hint(login_e2, "🔑 Enter your password", is_password=True)

# Login Button and "Forgot Password"
login_b1 = ttk.Button(login_frame, text="Login", style="TButton.Normal.TButton", cursor="hand2", command=handle_login_click)

# Button hover effect using styles
def on_enter(event):
    login_b1.config(style="TButton.Hover.TButton")

def on_leave(event):
    login_b1.config(style="TButton.Normal.TButton")

login_b1.bind("<Enter>", on_enter)
login_b1.bind("<Leave>", on_leave)

forgot_password_label = tk.Label(login_frame, text="Forgot Password?", font=("Helvetica", 10, "underline"), bg='#ffffff', fg='#3a86ff', cursor="hand2")
Signup_label = tk.Label(login_frame, text="Create New Account?", font=("Helvetica", 10, "underline"), bg='#ffffff', fg='#3a86ff', cursor="hand2")
Signup_label.bind("<Button-1>", lambda e: open_signup())

login_e1.pack(pady=(30, 5), ipadx=10, ipady=7)
login_e2.pack(pady=5, ipadx=10, ipady=7)
forgot_password_label.pack(pady=(10, 5))
login_b1.pack(pady=(30, 0))
Signup_label.pack(pady=(10, 5))

# ========================== SIGNUP FRAME ==========================
signup_frame = tk.Frame(root, width=350, height=450, bg='#ffffff', padx=50, pady=5)

# Image and Title for Signup
signup_im = PhotoImage(file="userlogin.png")
signup_ilabel = tk.Label(signup_frame, image=signup_im, bg='#ffffff')
signup_ilabel.pack(pady=(10, 10))
signup_title_label = tk.Label(signup_frame, text="Sign Up", font=("Helvetica", 24, "bold"), bg='#ffffff', fg='#333')
signup_title_label.pack(pady=(0, 20))

# Signup Entry Fields
signup_e1 = tk.Entry(signup_frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
signup_e2 = tk.Entry(signup_frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
signup_e3 = tk.Entry(signup_frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")
signup_e4 = tk.Entry(signup_frame, font=('Helvetica', 12), bd=0, relief=tk.FLAT, highlightbackground="#dddddd", highlightthickness=1, highlightcolor="#3a86ff")

add_hint(signup_e1, "👤 Enter your username")
add_hint(signup_e2, "📧 Enter your email")
add_hint(signup_e3, "🔑 Enter your password", is_password=True)
add_hint(signup_e4, "🔒 Confirm your password", is_password=True)

# Signup Button and "Already have an account?"
signup_b1 = ttk.Button(signup_frame, text="Sign Up", style="TButton.Normal.TButton", cursor="hand2", command=handle_signup_click)

Signup_label = tk.Label(signup_frame, text="Already have an Account?", font=("Helvetica", 10, "underline"), bg='#ffffff', fg='#3a86ff', cursor="hand2")
Signup_label.bind("<Button-1>", lambda e: open_login())

# Button hover effect
signup_b1.bind("<Enter>", on_enter)
signup_b1.bind("<Leave>", on_leave)

signup_e1.pack(pady=(25, 5), ipadx=10, ipady=7, fill=tk.X)
signup_e2.pack(pady=(15, 5), ipadx=10, ipady=7, fill=tk.X)
signup_e3.pack(pady=(15, 5), ipadx=10, ipady=7, fill=tk.X)
signup_e4.pack(pady=(15, 5), ipadx=10, ipady=7, fill=tk.X)
signup_b1.pack(pady=(30, 5), fill=tk.X)
Signup_label.pack()

# Start with login frame shown
login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

# Start the tkinter main loop
root.mainloop()
