---
name: Report bug
about: use this template to report bugs
title: Report bug
labels: bug
assignees: ''

---

- Briefly describe the bug
- Operating System
- What is the expected behavior?
- Please provide step by step instructions on how to reproduce the bug
